﻿using ProyectoDB.Models;
using ProyectoDB.Test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

public class ProductosController : Controller
{
    Datos db = new Datos();
    // GET: Productos
    public ActionResult Index()
    {
        List<Producto> Productos = db.Productos.ToList();
        return View(Productos);
    }

    public ActionResult Detalles(int id)
    {
        return View(db.Productos.Find(id));
    }
    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Create(Producto producto)
    {
        try
        {
            if (ModelState.IsValid)
            {
                db.Productos.Add(producto);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
        catch
        {
            return View();
        }
    }
    public ActionResult Edit(int id)
    {
        return View(db.Productos.Find(id));
    }
    [HttpPost]
    public ActionResult Edit(int id, Producto producto)
    {
        if (ModelState.IsValid)
        {
            db.Entry(producto).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");
        }
        else
        {
            return View();
        }
    }

    public ActionResult Delete(int id)
    {
        return View(db.Productos.Find(id));
    }

    [HttpPost]
    public ActionResult Delete(int id, Producto producto)
    {
        Producto P = db.Productos.Find(id);
        db.Productos.Remove(P);
        db.SaveChanges();
        return RedirectToAction("Index");
    }

}