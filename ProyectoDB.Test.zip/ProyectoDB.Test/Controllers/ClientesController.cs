﻿using ProyectoDB.Test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

public class ClientesController : Controller
{
    Datos db = new Datos();
    // GET: Clientes
    public ActionResult Index()
    {
        List<Cliente> clientes = db.Clientes.ToList();
        return View(clientes);
    }

    public ActionResult Detalles(int id)
    {
        return View(db.Clientes.Find(id));
    }
    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Create(Cliente cliente)
    {
        try
        {
            if (ModelState.IsValid)
            {
                db.Clientes.Add(cliente);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
        catch
        {
            return View();
        }
    }
    public ActionResult Edit(int id)
    {
        return View(db.Clientes.Find(id));
    }
    [HttpPost]
    public ActionResult Edit(int id, Cliente cliente)
    {
        if (ModelState.IsValid)
        {
            db.Entry(cliente).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");
        }
        else
        {
            return View();
        }
    }

    public ActionResult Delete(int id)
    {
        return View(db.Clientes.Find(id));
    }

    [HttpPost]
    public ActionResult Delete(int id, Cliente cliente)
    {
        Cliente c = db.Clientes.Find(id);
        db.Clientes.Remove(c);
        db.SaveChanges();
        return RedirectToAction("Index");
    }

}