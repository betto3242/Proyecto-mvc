﻿using ProyectoDB.Models;
using ProyectoDB.Test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoDB.Controllers
{
    public class EmpleadosController : Controller
    {
        Datos db = new Datos();
        // GET: Clientes
        public ActionResult Index()
        {
            List<Empleados> empleados = db.Empleados.ToList();
            return View(empleados);
        }

        public ActionResult Detalles(int id)
        {
            return View(db.Empleados.Find(id));
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Empleados empleados)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Empleados.Add(empleados);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }
        public ActionResult Edit(int id)
        {
            return View(db.Empleados.Find(id));
        }
        [HttpPost]
        public ActionResult Edit(int id, Empleados empleados)
        {
            if (ModelState.IsValid)
            {
                db.Entry(empleados).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            return View(db.Empleados.Find(id));
        }

        [HttpPost]
        public ActionResult Delete(int id, Empleados empleados)
        {
            Empleados E = db.Empleados.Find(id);
            db.Empleados.Remove(E);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}