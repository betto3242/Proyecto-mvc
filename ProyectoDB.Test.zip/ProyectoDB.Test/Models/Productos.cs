﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ProyectoDB.Models
{
    [Table("Productos")]
    public class Producto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //[Range(100, 9999,ErrorMessage = "Debe proporcionar un número entre 100 y 9999")]
        [DisplayName("ID")]
        public int IdProd { get; set; }
        [DisplayName("Descripcion")]
        [Required(ErrorMessage = "Debe proporcionar una descripción")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Debe de proporcionar al menos 2 caracteres y máximo 100 caracteres")]
        public string Descripcion { get; set; }
        [DisplayName("Existencia")]
        [Required(ErrorMessage = "Debe proporcionar la existencia")]
        public decimal Existencia { get; set; }
        [DisplayName("Precio Unitario")]
        [Required(ErrorMessage = "Debe proporcionar el precio unitario")]
        public decimal PrecioUnit { get; set; }
    }
}