﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ProyectoDB.Models
{
    [Table("Empleados")]
    public class Empleados
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //[Range(100, 9999,ErrorMessage = "Debe proporcionar un número entre 100 y 9999")]
        [DisplayName("ID")]
        public int IdEmp { get; set; }
        [DisplayName("Nombre")]
        [Required(ErrorMessage = "Debe proporcionar un nombre")]
        [StringLength(60, MinimumLength = 7, ErrorMessage = "Debe de proporcionar al menos 7 letras y máximo 60 letras")]
        public string NomEmp { get; set; }
        [DisplayName("Domicilio")]
        [Required(ErrorMessage = "Debe proporcionar un domicilio")]
        [StringLength(150, MinimumLength = 10, ErrorMessage = "Debe de proporcionar al menos 10 caracteres y máximo 150 caracteres")]
        public string DomEmp { get; set; }
        [DisplayName("Teléfono")]
        [Required(ErrorMessage = "Debe proporcionar un teléfono")]
        [RegularExpression(@"^(\d{10})$",ErrorMessage = "Formato de teléfono incorrecto")]
        public string CelEmp { get; set; }
        [DisplayName("Correo")]
        [Required(ErrorMessage = "Debe proporcionar un correo")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zAZ0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "El formato del correo electrónico es incorrecto")]
        public string Email { get; set; }
        //Constructor
        public Empleados(int id, string nom, string
        dom, string cel, string correo)
        {
            this.IdEmp = id;
            this.NomEmp = nom;
            this.DomEmp = dom;
            this.CelEmp = cel;
            this.Email = correo;
        }
        public Empleados()
        {
        }
    }
}